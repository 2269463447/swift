//
//  MapViewController.swift
//  SmartCar
//
//  Created by 赵贤斌 on 2023/3/29.
//

import UIKit
import MAMapKit
import AMapFoundationKit

class MapViewController: UIViewController, MAMapViewDelegate {
    
    var mapView = MAMapView()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        AMapServices.shared().apiKey = "498312ef4e4f30b647348216e2878aaf"
        AMapServices.shared()?.enableHTTPS = true
        mapView = MAMapView(frame: self.view.bounds)
        mapView.showsUserLocation = true
        mapView.isRotateEnabled = false // 禁止旋转手势
        mapView.userTrackingMode = .followWithHeading // 打开定位方向
        mapView.isRotateCameraEnabled = false // 禁止倾斜手势
        mapView.showsCompass = false // 禁止显示指南针
        mapView.delegate = self
        mapView.setZoomLevel(15.0, animated: true) // 默认缩放等级为15
        mapView.pausesLocationUpdatesAutomatically = false
        self.view.addSubview(mapView)
        
        let r = MAUserLocationRepresentation()
        r.showsAccuracyRing = false
        r.showsHeadingIndicator = true
        r.fillColor = UIColor.red
        r.strokeColor = UIColor.blue
        r.lineWidth = 2
        r.locationDotBgColor = UIColor.white
        r.locationDotFillColor = #colorLiteral(red: 0.2082370818, green: 0.6312591434, blue: 1, alpha: 1)
        r.image = UIImage(named: "图片")
        mapView.update(r)
        
        mapView.showsCompass = true
        mapView.compassOrigin = CGPoint(x: 100, y: 500)
        
        mapView.showsScale = true
        mapView.scaleOrigin = CGPoint(x: 10, y: 500)
        //指定屏幕中心点
        mapView.screenAnchor = CGPoint(x: 0.5, y: 0.5)
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        initAnnotationData()
    }
    
    
    func initAnnotationData() {
        
        let pointAnnotation = MAPointAnnotation()
        pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: 30.1, longitude: 120.478)
        pointAnnotation.title = "补货站1"
        pointAnnotation.subtitle = "赵贤斌大帅比开的"
        mapView.addAnnotation(pointAnnotation)
    }
    /**
     * @brief 根据anntation生成对应的View。
     * @param mapView 地图View
     * @param annotation 指定的标注
     * @return 生成的标注View
     */
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {

        if annotation.isKind(of: MAPointAnnotation.self) {
            if annotation.title != "当前位置" {
                let pointReuseIndetifier = "pointReuseIndetifier"
                var annotationView: MAPinAnnotationView? = mapView.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier) as! MAPinAnnotationView?

                if annotationView == nil {
                    annotationView = MAPinAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
                }

                annotationView!.canShowCallout = true
                annotationView!.animatesDrop = true
                annotationView!.isDraggable = true
                annotationView!.rightCalloutAccessoryView = UIButton(type: UIButton.ButtonType.detailDisclosure)

                return annotationView!
            }
        }

        return nil
    }
    
}
