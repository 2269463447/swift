//
//  LocationViewController.swift
//  SmartCar
//
//  Created by 赵贤斌 on 2023/3/17.
//

import UIKit
import MAMapKit
import AMapFoundationKit
import MapKit
import SwiftyJSON

@objcMembers
class LocationViewController: UIViewController, MAMapViewDelegate, UIScrollViewDelegate {
    var mapView = MAMapView()
    
    @IBOutlet weak var locationScrollView: UIScrollView!
    @IBOutlet weak var map: UIView!
    
    @IBOutlet weak var locationButton: UIButton!
    var location:[(String,String,CLLocationDegrees,CLLocationDegrees)] = []
//    typealias MKPositioningClosure = (String) -> ()
    //    var clousre : MKPositioningClosure?
    
    let locationManager = CLLocationManager()
    private var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        HttpTool.requestData(.get, URLString: "http://192.168.31.112:12001/stock/all") { result in
            let value = JSON(rawValue: result)
            print(value!["data"].count)
            let number = value!["data"].count-1
            self.locationScrollView.contentSize = CGSizeMake(ScreenW, CGFloat((number+1)*150+10))
            for i in 0...number{
                let name = value!["data"][i]
                print(value!["data"][i])
                self.location.append((name["name"].string!,name["address"].string!,name["latitude"].double!,name["longitude"].double!))
                self.collectionView.reloadData()
                self.locationScrollView.reloadInputViews()
                self.initAnnotationData(name["name"].string!,name["address"].string!,name["latitude"].double!,name["longitude"].double!)

            }
            self.collectionView.reloadData()
        } failure: { error in
            print(error)
        }

        
        //1.将两个经纬度点转成投影点
        
        
        //地图初始化
        AMapServices.shared().apiKey = "498312ef4e4f30b647348216e2878aaf"
        AMapServices.shared()?.enableHTTPS = true
        mapView = MAMapView(frame: self.view.bounds)
        mapView.showsUserLocation = true
        mapView.isRotateEnabled = false // 禁止旋转手势
        mapView.userTrackingMode = .followWithHeading // 打开定位方向
        mapView.isRotateCameraEnabled = false // 禁止倾斜手势
        mapView.showsCompass = false // 禁止显示指南针
        mapView.delegate = self
        mapView.setZoomLevel(12.0, animated: true) // 默认缩放等级为15
        mapView.pausesLocationUpdatesAutomatically = false
        self.view.addSubview(mapView)
        //        自定义小蓝点
        let r = MAUserLocationRepresentation()
        r.showsAccuracyRing = false
        r.showsHeadingIndicator = true
        r.fillColor = UIColor.red
        r.strokeColor = UIColor.blue
        r.lineWidth = 2
        r.locationDotBgColor = UIColor.white
        r.locationDotFillColor = #colorLiteral(red: 0.2082370818, green: 0.6312591434, blue: 1, alpha: 1)
        r.image = UIImage(named: "图片")
        mapView.update(r)
        
        
        
        
        locationManager.delegate = self    //要放在前面
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()    //请求位置信息/如果一直获取用startUpdatingLocation()
        
        
        
        
        
        
        //指南针
        mapView.showsCompass = true
        mapView.compassOrigin = CGPoint(x: 100, y: 480)
        //比例尺控件
        mapView.showsScale = true
        mapView.scaleOrigin = CGPoint(x: 10, y: 480)
        //指定屏幕中心点
        mapView.screenAnchor = CGPoint(x: 0.5, y: 0.5)
        
        
        
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .vertical
        flowLayout.itemSize = CGSize(width: 358, height: 140)
        flowLayout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        
        
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height), collectionViewLayout: flowLayout)
        collectionView.register(MyCollectionViewCell.self, forCellWithReuseIdentifier: "CellID")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = #colorLiteral(red: 0.9569018483, green: 0.9568391442, blue: 0.9732491374, alpha: 1)
        
//        for i in 0...location.count-1 {
//            initAnnotationData(location[i].0,location[i].1,location[i].2,location[i].3)
//        }
        
        locationScrollView.bounces = false
        locationScrollView.addSubview(collectionView)
        
        locationScrollView.delegate = self
        
        
        let frame = CGRect(x: 0, y: 0, width: ScreenW, height: 430)
        mapView.frame = frame
        let viewForMap = UIView(frame: frame)
        viewForMap.backgroundColor = .white
        viewForMap.addSubview(mapView)
        self.map.addSubview(viewForMap)
        self.map.addSubview(locationButton)
        
    }
    
    
    
    
    @IBAction func location(_ sender: UIButton) {
        locationManager.requestLocation()
        let lat = locationManager.location!.coordinate.latitude
        let lon = locationManager.location!.coordinate.longitude
        mapView.setCenter(CLLocationCoordinate2D(latitude: lat, longitude: lon), animated: true)
    }
    
}



//MARK: - 绘制标记点
extension LocationViewController {
    
    func initAnnotationData(_ title:String,_ subtitle:String,_ lat:CLLocationDegrees,_ lon:CLLocationDegrees) {
        let pointAnnotation = MAPointAnnotation()
        pointAnnotation.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        pointAnnotation.title = title
        pointAnnotation.subtitle = subtitle
        mapView.addAnnotation(pointAnnotation)
    }
    
    
    /**
     * @brief 根据anntation生成对应的View。
     * @param mapView 地图View
     * @param annotation 指定的标注
     * @return 生成的标注View
     */
    func mapView(_ mapView: MAMapView!, viewFor annotation: MAAnnotation!) -> MAAnnotationView! {
        
        if annotation.isKind(of: MAPointAnnotation.self) {
            if annotation.title != "当前位置" {
                let pointReuseIndetifier = "pointReuseIndetifier"
                var annotationView: MAPinAnnotationView? = mapView.dequeueReusableAnnotationView(withIdentifier: pointReuseIndetifier) as! MAPinAnnotationView?
                
                if annotationView == nil {
                    annotationView = MAPinAnnotationView(annotation: annotation, reuseIdentifier: pointReuseIndetifier)
                }
                
                annotationView!.canShowCallout = true
                annotationView!.animatesDrop = true
                annotationView!.isDraggable = true
                annotationView!.rightCalloutAccessoryView = UIButton(type: UIButton.ButtonType.detailDisclosure)
                
                return annotationView!
            }
        }
        
        return nil
    }
    
}


//MARK: - 获取定位点信息
extension LocationViewController: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
//            mapView.setCenter(CLLocationCoordinate2D(latitude: lat, longitude: lon), animated: true)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
}

//MARK: - 添加补货站信息卡片
extension LocationViewController {
    func addLocation( title:String, subtitle:String, distance: Float) -> UIView {
        let locationView = UIView(frame: CGRect(x: 5, y: 5, width: 330, height: 130) )
        locationView.addSubview(initTitleLabel(title: title))
        locationView.addSubview(initSubLabel(subtitle: subtitle))
        locationView.addSubview(initLabel())
        locationView.addSubview(initImage())
        locationView.addSubview(initImage2())
        locationView.addSubview(initImage3())
        locationView.addSubview(initDistance(distance: distance))
        locationView.backgroundColor = .white
        return locationView
    }
    func initLabel() -> UILabel{
        let label = UILabel()
        label.frame = CGRectMake(250, 10, 1, 110)
        label.backgroundColor = #colorLiteral(red: 0.7764705882, green: 0.7764705882, blue: 0.7843137255, alpha: 1)
        return label
    }
    func initTitleLabel(title:String) -> UILabel{
        let label = UILabel()
        label.frame = CGRect(x: 10, y: 10, width: 80, height: 20)
        label.text = title
        label.font = .boldSystemFont(ofSize: 15)
        return label
    }
    func initSubLabel(subtitle:String) -> TextUpperLeftLabel{
        let sublabel = TextUpperLeftLabel()
        sublabel.textColor = .gray
        sublabel.frame = CGRect(x: 10, y: 35, width: 230, height: 80)
        sublabel.numberOfLines = 0
        sublabel.text = "\(subtitle)\n\n营业时间：8:30-21:30"
        sublabel.font = .systemFont(ofSize: 13)
        return sublabel
    }
    func initDistance(distance: Float) -> UILabel {
        let label = UILabel()
        label.frame = CGRect(x: 270, y: 30, width: 100, height: 30)
        let jl = String(format:"%.1f",distance)
        label.text = "距离\(jl)km"
        label.font = .systemFont(ofSize: 13)
        label.textColor = .gray
        return label
    }
    func initImage() -> UIImageView{
        let imageView = UIImageView(frame: CGRect(x: 10, y: 100, width: 44, height: 20))
        imageView.image = UIImage(named: "营业中")
        return imageView
    }
    func initImage2() -> UIImageView {
        let imageView = UIImageView(frame: CGRect(x: 272, y: 70, width: 22, height: 22))
        imageView.image = UIImage(named: "定位点")
        return imageView
    }
    func initImage3() -> UIImageView {
        let imageView = UIImageView(frame: CGRect(x: 310, y: 70, width: 22, height: 22))
        imageView.image = UIImage(named: "电话")
        return imageView
    }

}
extension LocationViewController: UICollectionViewDelegate {
    
}
extension LocationViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return location.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell: UICollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellID", for: indexPath)
        locationManager.requestLocation()
        let lat = locationManager.location!.coordinate.latitude
        let lon = locationManager.location!.coordinate.longitude
        
        let point1 = MAMapPointForCoordinate(CLLocationCoordinate2D(latitude: lat, longitude: lon))
        let point2 = MAMapPointForCoordinate(CLLocationCoordinate2D(latitude: location[indexPath.item].2, longitude: location[indexPath.item].3))

        //2.计算距离
        let distance = MAMetersBetweenMapPoints(point1,point2);
        let distance2 = distance/1000
        
        cell.backgroundColor = .white
        cell.layer.cornerRadius = 15
        cell.dropShadow(color: .gray, opacity: 0.1, offSet: CGSize(width: 0, height: 0))
        cell.addSubview(addLocation(title: location[indexPath.item].0, subtitle: location[indexPath.item].1, distance: Float(distance2)))
        cell.isUserInteractionEnabled = true
        cell.tag = indexPath.item
        
//        let tap = UITapGestureRecognizer(target: self, action:#selector(tapClick(sender:)))
//        cell.addGestureRecognizer(tap)
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell: UICollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellID", for: indexPath)
        if cell.isSelected == true {
            mapView.setCenter(CLLocationCoordinate2D(latitude: location[indexPath.item].2, longitude: location[indexPath.item].3), animated: true)
        }
    }
}
