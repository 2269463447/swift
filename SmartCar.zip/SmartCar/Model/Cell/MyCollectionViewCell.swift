//
//  MyCollectionViewCell.swift
//  SmartCar
//
//  Created by 赵贤斌 on 2023/4/8.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    private var textLabel: UILabel!
    
    var cellIndex: Int = 0 {
        didSet {
            textLabel.text = "\(cellIndex+1)"
        }
    }
 
    override init(frame: CGRect) {
        super.init(frame: frame)
        textLabel = UILabel()
        textLabel.font = UIFont.systemFont(ofSize: 30)
        textLabel.textAlignment = .center
        contentView.addSubview(textLabel)
        backgroundColor = .orange
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        textLabel.frame = bounds
    }
    
    // 设置选中背景色
    override var isSelected: Bool {
        didSet {
            contentView.layer.cornerRadius = 15
            contentView.layer.borderWidth = 2
            if isSelected {
                contentView.layer.setBorderColorFromUIColor(color: .orange)
            } else {
                contentView.layer.setBorderColorFromUIColor(color: .white)
            }
            super.isSelected = isSelected
        }
    }
    
    // 设置高亮色
//    override var isHighlighted: Bool {
//        didSet {
//            if isHighlighted {
//                contentView.backgroundColor = .blue
//            } else {
//                contentView.backgroundColor = nil
//            }
//            super.isHighlighted = isHighlighted
//        }
//    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

